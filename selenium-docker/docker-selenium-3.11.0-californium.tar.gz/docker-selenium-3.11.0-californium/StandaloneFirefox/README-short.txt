Selenium Standalone configured to run Firefox
