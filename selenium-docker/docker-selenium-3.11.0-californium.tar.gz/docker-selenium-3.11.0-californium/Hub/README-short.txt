The Hub manages Nodes that can perform tests. When it receives a test to be executed, that responsibility is delegated to a Node that can do so.
