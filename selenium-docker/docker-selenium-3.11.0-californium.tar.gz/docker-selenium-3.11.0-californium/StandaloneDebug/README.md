# Debug image template

This folder serves as a template for creating standalone server debug images. Note usage in the Makefile at the root of this repo.
