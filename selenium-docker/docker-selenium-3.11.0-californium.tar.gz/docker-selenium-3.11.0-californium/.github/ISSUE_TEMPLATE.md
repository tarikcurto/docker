## Meta -
Image(s):  
<!-- node-chrome? hub? standalone-firefox? -->
Docker-Selenium Image Version(s):  
<!-- 3, 3.4, 3.11.0-californium etc -->
Docker Version:  
<!-- 17.09.0-ce, 17.06.2-ce etc -->
OS: 
<!-- Windows 10, OSX Yosemite, Centos6, etc -->

<!-- NOTE
FIREFOX 48+ IS ONLY COMPATIBLE WITH GECKODRIVER.

If the issue is with Google Chrome consider logging an issue with chromedriver instead:
https://sites.google.com/a/chromium.org/chromedriver/help

If the issue is with Firefox GeckoDriver (aka Marionette) consider logging an issue with Mozilla:
https://bugzilla.mozilla.org/buglist.cgi?product=Testing&component=Marionette

-->
## Expected Behavior -

## Actual Behavior -
