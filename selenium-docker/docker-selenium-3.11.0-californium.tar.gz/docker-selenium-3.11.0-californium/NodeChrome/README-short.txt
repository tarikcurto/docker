Selenium Node configured to run Google Chrome.
