_This image is not meant to be run directly!_ It serves as the base image used for Selenium Nodes.
