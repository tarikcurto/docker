Selenium Node configured to run Firefox
