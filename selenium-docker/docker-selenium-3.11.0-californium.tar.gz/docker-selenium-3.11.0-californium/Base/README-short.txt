_This image is not meant to be run directly!_ It serves as the base image used for each of the Selenium images involved in setting up a Selenium Grid.
