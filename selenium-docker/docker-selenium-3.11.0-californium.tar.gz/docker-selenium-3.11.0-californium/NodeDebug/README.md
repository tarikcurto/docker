# Debug image template

This folder serves as a template for creating debug images derived from Selenium Node Browser images. Note usage in the Makefile at the root of this repo.
