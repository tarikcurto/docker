Selenium Standalone configured to run ##BROWSER##
