# Debug image template

This folder servers as a template for creating standalone server images derived from Selenium Node Browser images. Note usage in the Makefile at the root of this repo.
